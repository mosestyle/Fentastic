# -*- coding: utf-8 -*-
import xbmc, xbmcgui

# from modules.logger import logger


def widget_monitor(list_id):
    if len(list_id) != 5:
        return
    monitor = xbmc.Monitor()
    window = None
    try:
        delay = float(xbmc.getInfoLabel("Skin.String(category_widget_delay)")) / 1000
    except:
        delay = 0.75
    display_delay = (
        xbmc.getInfoLabel("Skin.HasSetting(category_widget_display_delay)") == "True"
    )
    stack_id = list_id + "1"
    poster_toggle, landscape_toggle = True, False
    while not monitor.abortRequested():
        window_id = xbmcgui.getCurrentWindowId()
        if window_id not in [10000, 11121]:
            break
        else:
            window = xbmcgui.Window(window_id)
            stack_control = window.getControl(int(stack_id))
            stack_label_control = (
                window.getControl(int(stack_id + "666"))
                or window.getControl(int(stack_id + "667"))
                or window.getControl(int(stack_id + "668"))
                or window.getControl(int(stack_id + "669"))
                or window.getControl(int(stack_id + "670"))
                or window.getControl(int(stack_id + "671"))
                or window.getControl(int(stack_id + "672"))
            )
        monitor.waitForAbort(0.25)
        if list_id != str(window.getFocusId()):
            break
        last_path = window.getProperty("fentastic.%s.path" % list_id)
        cpath_path = xbmc.getInfoLabel("ListItem.FolderPath")
        if last_path == cpath_path or xbmc.getCondVisibility(
            "System.HasActiveModalDialog"
        ):
            continue
        switch_widget = True
        countdown = delay
        while not monitor.abortRequested() and countdown >= 0 and switch_widget:
            monitor.waitForAbort(0.25)
            countdown -= 0.25
            if list_id != str(window.getFocusId()):
                switch_widget = False
            if last_path == cpath_path:
                switch_widget = False
            if xbmc.getInfoLabel("ListItem.FolderPath") != cpath_path:
                switch_widget = False
            if xbmc.getCondVisibility("System.HasActiveModalDialog"):
                switch_widget = False
            if xbmcgui.getCurrentWindowId() not in [10000, 11121]:
                switch_widget = False
            widget_label = xbmc.getInfoLabel("ListItem.Label")
            if display_delay:
                stack_label_control.setLabel(
                    "Loading [COLOR accent_color][B]{}[/B][/COLOR] in [B]%0.2f[/B] seconds".format(
                        widget_label
                    )
                    % (countdown)
                )
        if switch_widget:
            position = int(xbmc.getInfoLabel("Container(%s).Position" % list_id))
            cpath_label = xbmc.getInfoLabel("ListItem.Label")
            stack_label_control.setLabel(cpath_label)
            window.setProperty("fentastic.%s.label" % list_id, cpath_label)
            window.setProperty("fentastic.%s.path" % list_id, cpath_path)
            monitor.waitForAbort(0.2)
            update_wait_time = 0
            while (
                xbmc.getCondVisibility("Container(%s).IsUpdating" % stack_id)
                and not update_wait_time > 3
            ):
                monitor.waitForAbort(0.10)
                update_wait_time += 0.10
            monitor.waitForAbort(0.50)
            try:
                stack_control.selectItem(0)
            except:
                pass
        else:
            stack_label_control.setLabel(
                window.getProperty("fentastic.%s.label" % list_id)
            )
            monitor.waitForAbort(0.25)
    try:
        del monitor
    except:
        pass
    try:
        del window
    except:
        pass


def open_widget_path():
    """Open the focused widget item's folder path in the Videos window.

    This helps plugin items that show a dialog and then update the current
    container, such as POV's Genre Multiselect, work correctly from Home
    category widgets instead of being executed directly on the Home window.
    """
    path = xbmc.getInfoLabel("ListItem.FolderPath") or xbmc.getInfoLabel("ListItem.FileNameAndPath")
    if not path:
        try:
            xbmcgui.Dialog().notification("FENtastic", "No path found for this widget item", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception:
            pass
        return
    safe_path = path.replace('"', '\"')
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % safe_path)


def _quote_builtin_path(path):
    """Quote a Kodi path safely enough for use inside a builtin call."""
    if not path:
        return ""
    return path.replace('"', '\\"')


def _wait_for_window(window_id, timeout=3.0):
    monitor = xbmc.Monitor()
    waited = 0.0
    while not monitor.abortRequested() and waited < timeout:
        if xbmcgui.getCurrentWindowId() == window_id:
            return True
        monitor.waitForAbort(0.1)
        waited += 0.1
    return False


def _wait_for_container(timeout=3.0):
    monitor = xbmc.Monitor()
    waited = 0.0
    while not monitor.abortRequested() and waited < timeout:
        if not xbmc.getCondVisibility("Container.IsUpdating"):
            return True
        monitor.waitForAbort(0.1)
        waited += 0.1
    return False


def _possible_parent_paths(list_id=None, item_path=""):
    """Return possible widget parent folder paths while still on Home.

    The normal Container.FolderPath label can be empty on FENtastic home
    widgets. Reading it from the focused control id is more reliable.
    """
    paths = []

    def add(label):
        try:
            value = xbmc.getInfoLabel(label)
        except Exception:
            value = ""
        if value:
            paths.append(value)

    if list_id:
        add("Container(%s).FolderPath" % list_id)

    try:
        current_window = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        focus_id = current_window.getFocusId()
        if focus_id:
            add("Container(%s).FolderPath" % focus_id)
    except Exception:
        pass

    add("Container.FolderPath")

    clean = []
    item_l = (item_path or "").lower()
    for path in paths:
        path_l = path.lower()
        if not path or path == item_path:
            continue
        if "plugin.video.pov" not in path_l:
            continue
        if item_l and path_l == item_l:
            continue
        if path not in clean:
            clean.append(path)
    return clean


def _clean_kodi_path(path):
    if not path:
        return ""
    return path.replace("&amp;", "&").strip()


def pov_multiselect_widget(list_id=None, parent_path=None):
    """Run POV's Genre Multiselect correctly from a FENtastic home widget.

    v5 improvement:
    The skin now passes the widget source path as parent_path. That lets us
    open the real POV Genres folder instead of Kodi's Videos root before
    running POV's Multiselect action. The Back stack should therefore return to
    the POV Genres folder/results flow, not Files / Playlists / Video add-ons.
    """
    item_path = _clean_kodi_path(
        xbmc.getInfoLabel("ListItem.FolderPath")
        or xbmc.getInfoLabel("ListItem.FileNameAndPath")
    )
    parent_path = _clean_kodi_path(parent_path)

    if not item_path:
        try:
            xbmcgui.Dialog().notification(
                "FENtastic",
                "No POV Multiselect path found",
                xbmcgui.NOTIFICATION_INFO,
                3000,
            )
        except Exception:
            pass
        return

    item_path_l = item_path.lower()
    if "plugin.video.pov" not in item_path_l or "multiselect" not in item_path_l:
        xbmc.executebuiltin(
            'ActivateWindow(Videos,"%s",return)' % _quote_builtin_path(item_path)
        )
        return

    parent_path_l = parent_path.lower()
    if not parent_path or "plugin.video.pov" not in parent_path_l or parent_path == item_path:
        parent_paths = _possible_parent_paths(list_id=list_id, item_path=item_path)
        parent_path = parent_paths[0] if parent_paths else "plugin://plugin.video.pov/"

    # Open a real POV container, never Kodi's Videos root. This is needed
    # because POV's Multiselect updates the current video container after OK.
    xbmc.executebuiltin(
        'ActivateWindow(Videos,"%s",return)' % _quote_builtin_path(parent_path)
    )
    _wait_for_window(10025, 3.0)  # MyVideoNav / Videos window
    _wait_for_container(3.0)

    # Execute the focused Multiselect item as a plugin action. Do not open it as
    # the window path, otherwise Kodi can show the dialog twice or end blank.
    xbmc.executebuiltin('RunPlugin("%s")' % _quote_builtin_path(item_path))
